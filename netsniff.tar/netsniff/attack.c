#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/ether.h>
#include <netinet/ip.h>
#include <unistd.h>
#include <errno.h>
#include <pcap.h>
#include <libnet.h>
#include <pthread.h>
#include "nethack.h"

/* define		*/
char	*dev = "wlan0";
char	*s_ip = "183.111.172.9";	/* 아시아경제 신문사	*/
int		s_port = 80;


/* global		*/
char	interface[12];
char	gateway[16];
char	target[16];

/***********************************************************
 * main()
 **********************************************************/
int main(int argc, char *argv[])
{
	int retc;
	char ebuf[BUFSIZ];
	pthread_t tid, tpack, tarp1, tarp2;

	if (argc != 4)
	{
		printf("%s interface gateway target\n", argv[0]);
		return 0;
	}

	memset(interface, 0x00, sizeof(interface));
	strcat(interface, argv[1]);
	memset(gateway, 0x00, sizeof(gateway));
	strcat(gateway, argv[2]);
	memset(target, 0x00, sizeof(target));
	strcat(target, argv[3]);

#if 1
	arpspoof(NULL, interface, target, gateway);
#else
	arpspoof(NULL, interface, gateway, target);
#endif

	exit(0);
}
