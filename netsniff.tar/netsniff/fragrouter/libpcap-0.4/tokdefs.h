/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_PCAP_Y_TAB_H_INCLUDED
# define YY_PCAP_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int pcap_debug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    DST = 258,                     /* DST  */
    SRC = 259,                     /* SRC  */
    HOST = 260,                    /* HOST  */
    GATEWAY = 261,                 /* GATEWAY  */
    NET = 262,                     /* NET  */
    MASK = 263,                    /* MASK  */
    PORT = 264,                    /* PORT  */
    LESS = 265,                    /* LESS  */
    GREATER = 266,                 /* GREATER  */
    PROTO = 267,                   /* PROTO  */
    BYTE = 268,                    /* BYTE  */
    ARP = 269,                     /* ARP  */
    RARP = 270,                    /* RARP  */
    IP = 271,                      /* IP  */
    TCP = 272,                     /* TCP  */
    UDP = 273,                     /* UDP  */
    ICMP = 274,                    /* ICMP  */
    IGMP = 275,                    /* IGMP  */
    IGRP = 276,                    /* IGRP  */
    ATALK = 277,                   /* ATALK  */
    DECNET = 278,                  /* DECNET  */
    LAT = 279,                     /* LAT  */
    SCA = 280,                     /* SCA  */
    MOPRC = 281,                   /* MOPRC  */
    MOPDL = 282,                   /* MOPDL  */
    TK_BROADCAST = 283,            /* TK_BROADCAST  */
    TK_MULTICAST = 284,            /* TK_MULTICAST  */
    NUM = 285,                     /* NUM  */
    INBOUND = 286,                 /* INBOUND  */
    OUTBOUND = 287,                /* OUTBOUND  */
    LINK = 288,                    /* LINK  */
    GEQ = 289,                     /* GEQ  */
    LEQ = 290,                     /* LEQ  */
    NEQ = 291,                     /* NEQ  */
    ID = 292,                      /* ID  */
    EID = 293,                     /* EID  */
    HID = 294,                     /* HID  */
    LSH = 295,                     /* LSH  */
    RSH = 296,                     /* RSH  */
    LEN = 297,                     /* LEN  */
    OR = 298,                      /* OR  */
    AND = 299,                     /* AND  */
    UMINUS = 300                   /* UMINUS  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif
/* Token kinds.  */
#define YYEMPTY -2
#define YYEOF 0
#define YYerror 256
#define YYUNDEF 257
#define DST 258
#define SRC 259
#define HOST 260
#define GATEWAY 261
#define NET 262
#define MASK 263
#define PORT 264
#define LESS 265
#define GREATER 266
#define PROTO 267
#define BYTE 268
#define ARP 269
#define RARP 270
#define IP 271
#define TCP 272
#define UDP 273
#define ICMP 274
#define IGMP 275
#define IGRP 276
#define ATALK 277
#define DECNET 278
#define LAT 279
#define SCA 280
#define MOPRC 281
#define MOPDL 282
#define TK_BROADCAST 283
#define TK_MULTICAST 284
#define NUM 285
#define INBOUND 286
#define OUTBOUND 287
#define LINK 288
#define GEQ 289
#define LEQ 290
#define NEQ 291
#define ID 292
#define EID 293
#define HID 294
#define LSH 295
#define RSH 296
#define LEN 297
#define OR 298
#define AND 299
#define UMINUS 300

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 82 "grammar.y"

	int i;
	bpf_u_int32 h;
	u_char *e;
	char *s;
	struct stmt *stmt;
	struct arth *a;
	struct {
		struct qual q;
		struct block *b;
	} blk;
	struct block *rblk;

#line 171 "y.tab.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE pcap_lval;


int pcap_parse (void);


#endif /* !YY_PCAP_Y_TAB_H_INCLUDED  */
