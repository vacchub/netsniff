#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

void dumphex(const void* data, int size) 
{
	char ascii[17];
	int ii, jj;

	ascii[16] = '\0';
	for (ii = 0; ii < size; ++ii) 
	{
		printf("%02X ", ((unsigned char*)data)[ii]);
		if (((unsigned char*)data)[ii] >= ' ' && ((unsigned char*)data)[ii] <= '~') 
			ascii[ii % 16] = ((unsigned char*)data)[ii];
		else 
			ascii[ii % 16] = '.';

		if ((ii+1) % 8 == 0 || ii+1 == size) 
		{
			printf(" ");
			if ((ii+1) % 16 == 0) 
			{
				printf("|  %s \n", ascii);
			} 
			else if (ii+1 == size) 
			{
				ascii[(ii+1) % 16] = '\0';
				if ((ii+1) % 16 <= 8)
					printf(" ");
				for (jj = (ii+1) % 16; jj < 16; ++jj) 
					printf("   ");
				printf("|  %s \n", ascii);
			}
		}
	}
}

int hacklog(char *fname, const void *data, int length)
{
	FILE *fp;
	struct tm *tm;
	time_t tt;
	char path[256];
	char buf[4*1024];
	char ascii[17];
	int ii, jj;

	if (fname == NULL)
		return 0;

	if (strlen(fname) == 0)
		return 0;


	sprintf(path, "../log/%s", fname);
	fp = fopen(path, "a+");
	if (fp == NULL)
		return -1;

	tt = time(NULL);
	tm = localtime(&tt);
	memset(buf, 0x00, sizeof(buf));
	sprintf(buf, "[%02d:%02d:%02d] pid[%d] length[%d]\n", 
			tm->tm_hour, tm->tm_min, tm->tm_sec, getpid(), length);
	fprintf(fp, buf);

	ascii[16] = '\0';
	for (ii = 0; ii < length; ++ii) 
	{
		fprintf(fp, "%02X ", ((unsigned char*)data)[ii]);
		if (((unsigned char*)data)[ii] >= ' ' && ((unsigned char*)data)[ii] <= '~') 
			ascii[ii % 16] = ((unsigned char*)data)[ii];
		else 
			ascii[ii % 16] = '.';

		if ((ii+1) % 8 == 0 || ii+1 == length) 
		{
			fprintf(fp, " ");
			if ((ii+1) % 16 == 0) 
			{
				fprintf(fp, "|  %s \n", ascii);
			} 
			else if (ii+1 == length) 
			{
				ascii[(ii+1) % 16] = '\0';
				if ((ii+1) % 16 <= 8)
					fprintf(fp, " ");
				for (jj = (ii+1) % 16; jj < 16; ++jj) 
					fprintf(fp, "   ");
				fprintf(fp, "|  %s \n", ascii);
			}
		}
	}
	
	fflush(fp);
	fclose(fp);
	return 0;
}
