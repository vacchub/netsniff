#ifndef SNIFF_H
#define SNIFF_H

typedef void (*sniff_handler)(u_char *pkt, int len);

int sniff_init(char *intf, char *ebuf);

void sniff_loop();

#endif /* SNIFF_H */
