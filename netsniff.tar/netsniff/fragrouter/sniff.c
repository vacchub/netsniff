#include <stdio.h>
#include <sys/param.h>
#include <pcap.h>
#include <libnet.h>
#include "sniff.h"
#include "send.h"

pcap_t *sniff_pd;
int sniff_ll_len;

int sniff_init(char *intf, char *ebuf)
{
  char *dev, filter[BUFSIZ];
  struct link_int *llif;
  struct ether_addr *llmac;
  u_long llip;
  u_int net, mask;
  struct bpf_program fcode;

  /* Get interface. */
  if (intf) dev = intf;
  else if (!(dev = pcap_lookupdev(ebuf)))
    return 0;

  /* Get interface IP and MAC address and link layer header length. */
  if (!(llif = libnet_open_link_interface(dev, ebuf)))
    return 0;

  if (!(llip = libnet_get_ipaddr(llif, dev, ebuf)))
    return 0;

  if (!(llmac = libnet_get_hwaddr(llif, dev, ebuf)))
    return 0;

  libnet_close_link_interface(llif);

  llip = ntohl(llip);
 
  if (!llif->linkoffset)
    sniff_ll_len = 14; /* XXX - assume Ethernet, if libnet fails us here. */
  else 
    sniff_ll_len = llif->linkoffset;

  /* Generate packet filter. We aren't sniffing in promiscuous mode,
     but be specific in case someone else is. */
  snprintf(filter, sizeof(filter),
	   "ip and ether dst %x:%x:%x:%x:%x:%x and not dst %s and not ip broadcast",
	   llmac->ether_addr_octet[0], llmac->ether_addr_octet[1],
	   llmac->ether_addr_octet[2], llmac->ether_addr_octet[3],
	   llmac->ether_addr_octet[4], llmac->ether_addr_octet[5],
	   libnet_host_lookup(llip, 0));
#ifdef DEBUG
  fprintf(stderr, "fragrouter: %s\n", filter);
#endif /* DEBUG */
  
  /* Open interface for sniffing, don't set promiscuous mode. */
  if (pcap_lookupnet(dev, &net, &mask, ebuf) == -1)
    return 0;

  if (!(sniff_pd = pcap_open_live(dev, 2048, 0, 1024, ebuf)))
    return 0;
  
  if (pcap_compile(sniff_pd, &fcode, filter, 1, mask) < 0) {
    strcpy(ebuf, pcap_geterr(sniff_pd));
    return 0;
  }
  if (pcap_setfilter(sniff_pd, &fcode) == -1) {
    strcpy(ebuf, pcap_geterr(sniff_pd));
    return 0;
  }
#ifdef DEBUG
  fprintf(stderr, "fragrouter: sniffing on %s\n", dev);
#endif /* DEBUG */
  
  return 1;
}

void sniff_loop()
{
  struct pcap_pkthdr pkthdr;
  struct ip *iph;
  u_char *pkt;
  int len;
  
  for (;;) {
    if ((pkt = (char *)pcap_next(sniff_pd, &pkthdr)) != NULL) {
      iph = (struct ip *)(pkt + sniff_ll_len);

      len = ntohs(iph->ip_len);
      if (len > pkthdr.len)
	    len = pkthdr.len;
      
      send_packet(pkt + sniff_ll_len, len);
    }
  }
}
