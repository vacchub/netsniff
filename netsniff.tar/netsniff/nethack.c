#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "nethack.h"

void usage()
{
	printf("Usage : nethack interface gateway-ip\n");
}

/***********************************************************
 * main()
 **********************************************************/
int main(int argc, char *argv[])
{
	handle hand;
	char interface[12], gateway[16];
	int retc;

	if (argc != 3)
	{
		usage();
		return 0;
	}

	memset(interface, 0x00, sizeof(interface));
	memcpy(interface, argv[1], strlen(argv[1]));
	memset(gateway, 0x00, sizeof(gateway));
	memcpy(gateway, argv[2], strlen(argv[2]));

	retc = network_analysis(&hand, interface, gateway);
	if (retc < 0)
	{
		printf("network_analysis() error\n");
		return -1;
	}

	printf("host [%s] [%08X]\n", inet_ntoa(hand.host), hand.host);
	printf("gateway [%s] [%08X]\n", inet_ntoa(hand.gateway), hand.gateway);
	printf("netmask [%s] [%08X]\n", inet_ntoa(hand.netmask), hand.netmask);
	printf("mac [%02x:%02x:%02x:%02x:%02x:%02x]\n", 
	hand.mac[0], hand.mac[1], hand.mac[2],
	hand.mac[3], hand.mac[4], hand.mac[5]);
	printf("-----------------------------------\n");

	network_search(&hand);

	for (;;)
	{
		usleep(100000);
	}

	return 0;
}
