#include <stdio.h>
#include <errno.h>
#include <libnet.h>
#include "print.h"
#include "send.h"

static int raw_socket = -1;
static struct ipoption *sropt = NULL;
static int sroptlen = 0;

int send_init(char *ebuf, char *hops, int hopptr)
{
  u_char *p, *q, optdata[MAX_IPOPTLEN];
  int optlen;

  if (hops && hops[0] != '\0') {
    if ((sropt = malloc(sizeof(*sropt))) == NULL) {
      perror("malloc");
      return 0;
    }
    q = optdata;
    p = strtok(hops, " ");
    for (; q - optdata < MAX_IPOPTLEN && p != NULL; p = strtok(NULL, " ")) {
      *((u_long *)q) = libnet_name_resolve(p, 1);
      q += 4;
    }
    optlen = q - optdata;
    sroptlen = 3 + optlen;
    
    memcpy(sropt->ipopt_list + 3, optdata, optlen);

    *(sropt->ipopt_list) = 0x83; /* LSRR */
    *(sropt->ipopt_list + 1) = sroptlen;
    *(sropt->ipopt_list + 2) = hopptr;
  }
  raw_socket = libnet_open_raw_sock(IPPROTO_RAW);
  if (raw_socket == -1) {
    strcpy(ebuf, strerror(errno));
    return 0;
  }
  return 1;
}

int send_packet(u_char *pkt, int pktlen)
{
  static u_char opkt[IP_MAXPACKET];
  struct ip *iph = (struct ip *)pkt;
  
  /* Sanity checking. */
  if (pktlen < ntohs(iph->ip_len)) return 0;
  
  /* Insert LSRR option, if any. */
  if (sropt) {
    /* XXX - ugh, suk. */
    memcpy(opkt, pkt, pktlen);
    
    if (libnet_insert_ipo(sropt, sroptlen, opkt) == -1) {
      perror("libnet_insert_ipo");
      return 0;
    }
    iph = (struct ip *)opkt;
    pkt = opkt;
  }
  pktlen = ntohs(iph->ip_len);

  while (libnet_write_ip(raw_socket, pkt, pktlen) != pktlen) {
    perror("libnet_write_ip");
    printf("send_packet failed: ");
    print_ip(pkt, pktlen);
    printf("\n");
    return 0;
  }
  /* Print tcpdump-style output. */
  print_ip(pkt, pktlen);
//  printf("\n");

  return 1;
}
