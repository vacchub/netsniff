#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include "sniff.h"
#include "send.h"

int main(int argc, char *argv[])
{
  char ebuf[BUFSIZ], hops[BUFSIZ], *dev = NULL;
  int hopptr = 4;

  hops[0] = '\0';
  
  if (!sniff_init(dev, ebuf)) {
    fprintf(stderr, "fragrouter: sniff_init failed: %s\n", ebuf);
    exit(1);
  }
  if (!send_init(ebuf, hops, hopptr)) {
    fprintf(stderr, "fragrouter: send_init failed: %s\n", ebuf);
    exit(1);
  }
  
  sniff_loop();

  exit(0);
}
