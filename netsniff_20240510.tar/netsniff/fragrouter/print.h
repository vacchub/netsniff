#ifndef _PRINT_H
#define _PRINT_H

void print_ip(unsigned char *bp, int length);

void print_tcp(unsigned char *bp, int length);

void print_udp(unsigned char *bp, int length);

void print_icmp(unsigned char *bp, int length);

#endif /* _PRINT_H */
