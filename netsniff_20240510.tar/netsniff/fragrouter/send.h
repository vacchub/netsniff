#ifndef SEND_H
#define SEND_H

int send_init(char *ebuf, char *hops, int hopptr);

int send_packet(u_char *pkt, int pktlen);

#endif /* SEND_H */
